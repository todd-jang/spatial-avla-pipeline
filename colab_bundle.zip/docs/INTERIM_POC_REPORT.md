# Interim PoC Report — spatial-avla-pipeline

**Date:** 2026-10-06 · **Plan:** `spatial-avla-poc.md` · **Status:** interim, 2 of 16 todos open
**Test suite:** 187 passed, 1 skipped · **Errors in pipeline run:** 0

---

## 1. Scope — what this PoC is and is not

This PoC validates the **spatial audio sensing chain**: a LangGraph pipeline that ingests
stereo dashcam audio, estimates sound direction of arrival (DoA), detects an emergency-siren
event via hysteresis, and renders the result into a 2×2 multi-view HUD.

It does **not** validate a siren-detection model. Nothing is trained. `mAP = 0.0` in the
report is the literal truth: there is no detector to score. The training harness exists and
is wired, but its GPU step is blocked (see §6).

---

## 2. Quantitative results

### 2.1 Pipeline integrity and latency

| Metric | Measured | Requirement | Margin |
|---|---|---|---|
| Frame latency p50 | **2.89 ms** | — | — |
| Frame latency p95 | **3.38 ms** | < 330 ms | **98% headroom** |
| `T_last` | 1,791,198,479,546 ms | > 0 | ✅ |
| `Errors_Count` | **0** | 0 | ✅ |
| `All_OK` | **true** | true | ✅ |
| Fallback path | absent | absent | ✅ |

Latency is measured on the Gradio fast path (`GraphBridge fast_mode=True`), which
deliberately skips the JSON-schema validator and metrics node. The full-graph path is
therefore **not** covered by this number and would be substantially slower.

### 2.2 Spatial audio — DoA estimator accuracy

**Ideal sweep, 13 static angles (−90°…+90°, step 15°), no noise:**

```
n = 13    ambiguous = 0/13    max |err| = 0.0886°    mean |err| = 0.0412°
confidence ∈ [0.587, 0.651]
```

Against the plan's ≤ 2.0° gate, this is **~23× inside tolerance**. Every one of the 13
angles falls in the `[0, 0.1)` error bin.

**Noise robustness** (post-clamp, all 13 angles, zero ambiguous in every row):

| Noise | SNR 20 dB | SNR 15 dB | SNR 10 dB | SNR 5 dB |
|---|---|---|---|---|
| White — mean | 0.47° | 0.52° | 0.93° | 1.86° |
| White — max | 1.18° | 1.84° | 2.45° | 4.08° |
| Road — mean | 0.36° | — | 0.99° | 1.61° |
| Road — max | 1.00° | — | 3.17° | 5.28° |

Road noise (a 90/180/360/720/1440 Hz lowpassed composite standing in for tyre and wind) is
the harsher case at low SNR, but only in max error; its mean stays near 1.6°. No gate was
relaxed to achieve these.

**On real clip audio** (downloaded YouTube dashcam, AAC-compressed, resampled to 16 kHz
stereo, synthetic siren mixed at a measured 12.00 dB SNR) — measured during this review:

| Clip | Condition | Mean abs err | Scored windows |
|---|---|---|---|
| C01 | Seoul day | **3.06°** | 211 |
| C02 | Seoul Gwanghwamun, heavy rain | **2.79°** | 436 |
| C04 | Seoul Sanggye→Mokdong, night | **2.45°** | 436 |

This is the single most important number in the report: **the binaural cues survive
YouTube's codec and a 48 kHz→16 kHz resample.** The audio quality concern is empirically
not the binding constraint.

### 2.3 Event trigger (S_B)

| Track | True peak rate | Agent peak MA | Fired | Expected |
|---|---|---|---|---|
| `track_pass_fast` | 274.435 °/s | 220.643 °/s | **true** | fire ✅ |
| `track_pass_fast_left` (LHD mirror) | 274.435 °/s | 220.643 °/s | **true** | fire ✅ |
| `track_fail_slow` | 10.0 °/s | 10.0 °/s | false | silent ✅ |
| `track_static_left` | 0.0 °/s | 0.0 °/s | false | silent ✅ |
| `track_static_right` | 0.0 °/s | 0.0 °/s | false | silent ✅ |

The LHD mirror `track_pass_fast_left` fires identically to its right-side twin: the FSM rates
the abs-valued `|Δdoa|`, so handedness cannot change the trigger. The agent reads ~20% *below*
the true peak on the fast pass. This is correct behaviour, not
error: the estimator flags the ±90° representability boundary as ambiguous, those frames
contribute zero rate by design, and the 5-frame moving average therefore cannot see the
full excursion. Threshold is 120 °/s, giving ~1.8× margin over the silent tracks.

### 2.4 Dataset inventory

```
TOTAL clean ambient audio: 60.0 s  (1.00 min)
  C01  15.0s  Seoul day            450 frames  siren mix @ 12.00 dB  probe=high
  C02  15.0s  Seoul, heavy rain    451 frames  siren mix @ 12.00 dB  probe=high
  C04  15.0s  Seoul night          451 frames  siren mix @ 12.00 dB  probe=high
  T09  15.0s  test-only, NO siren  450 frames  (correct: never in train/)
```

**3 of 7 train clips. 4 blocked** (C03, C05, C06, C07) by YouTube's "Sign in to confirm
you're not a bot" IP-level gate. Single country (KR), single scenario group (`S1_korea`).
Total corpus including siren-mixed copies: **2 minutes**.

### 2.5 Regression coverage

188 tests across 14 files. Notably `test_head_radius_declared_exactly_once` asserts the
head-radius literal appears in exactly one `.py` file — a structural guard against the
silent 2.7° systematic error that a renderer/estimator radius mismatch would introduce.

---

## 3. Qualitative assessment

### What is genuinely strong

**The estimator is the standout result.** Sub-0.1° on ideal input and 1–2° under 5 dB road
noise is a strong GCC-PHAT implementation. More importantly, it is *honest*: when the
correlation peak implies a lag beyond `MAX_ITD = 10.493` samples, it returns
`ambiguous: true` rather than a confident wrong number. The negative-control experiment in
the evidence is telling — removing the coherence gate lowers mean error (14.34° → 5.26°) but
only by returning plausible-but-wrong values at ±90° (`gt -90 → -78.93`). **Trading an
honest ambiguity flag for silent error is a bad trade, and this codebase declined it.**

**Fail-loud discipline is real, not decorative.** Verified by execution, not assertion:
attempting to write test-only T09 into `train/` exits 2 and writes nothing; a missing raw
mp4 emits `SKIP … wrote nothing` rather than a truncated wav; a disk preflight refuses
rather than filling a 98%-full volume; `poc_completed_at_ms` is separated from `poc_all_ok`
so timing can't masquerade as success; `build_poc_report.py` refuses to emit a report with a
silently missing scenario group.

**Stereo integrity holds where it matters.** The 2-channel tensor is preserved through
ingest and asserted `shape[1] == 2` *before* a derived mono copy is made for WavLM, which
is mono-only. The mono copy is never written back. The original unmixed audio is never the
mix target, so with/without-siren runs stay comparable.

**Scenario labelling is derived, not asserted.** `scenario` is computed from the recorded
`country` via a lookup, so a mislabel surfaces as `scenario_mismatch` instead of hiding.
This immediately caught C01's pre-existing `clip_meta.json` claiming `scenario="S2_global"`
while `country="KR"`.

### What is honest but limited

The evidence files are unusually candid — they record a coherence-gate negative control that
**failed to reproduce** the plan's predicted behaviour, and explicitly decline to write the
test that would have asserted it ("asserting it would fabricate evidence"). They also record
a rejected 1-second-window change that improved noise behaviour while breaking the ideal
gate. That is the right instinct.

### Defects found during this review — disclosed, not fixed

1. **`build_poc_report.py:117` (`clip_metrics`) scores out-of-domain windows.** The renderer
   emits raw angles to 178.41°; the binaural pair structurally cannot report past ±90°;
   `wrap180(178.41)` returns `178.41` unchanged. 225 of C01's 436 windows are therefore
   scored against an unobservable label, inflating its mean error from **3.06° to 52.21°**.
   Filtering to `|gt| ≤ 90` recovers 3.06°, consistent with C02/C04.
2. **`outputs/poc_report.json` was stale — resolved.** It had published `track_pass_fast` at
   **744.955 °/s** while current code produces **220.643 °/s**. The artifact was regenerated
   and now matches the code, including the new `track_pass_fast_left` row (220.643 °/s, fires).
3. **Unexplained non-monotonicity at `nfft=32768`** in the window-length sweep — a ~60×
   outlier against both neighbouring coherence spans. Recorded as UNRESOLVED in todo 12
   evidence and still open.

---

## 4. What this PoC does **not** demonstrate

- **Any siren-detection accuracy.** No model is trained. `mAP = 0.0`. The smoke-training
  target is window-RMS-above-median on the clip's own audio — a loudness task, explicitly
  labelled `task_note: "harness smoke test only; not a siren-detection accuracy claim"`.
- **Anything about real sirens.** Every DoA figure is `source: "synthetic"`. What has been
  proven is *synthetic source in real noise*. The source model itself — a harmonic stack
  (325/430/650 Hz) under a 2.2 Hz wail, spatialised by Woodworth ITD — is unvalidated
  against real emergency sirens.
- **Anything on the vision side.** `vision_anomaly_score` is a mock defaulting to `0.2`.
  There is no `models/` directory.
- **Full-graph latency.** The 3.38 ms p95 is the fast path only.
- **Generalisation.** 1 minute of audio, 3 train clips, one country, one condition set.

---

## 5. Verdict

**The measurement and plumbing are sound. The product is unproven.**

The PoC has established something worth having: a spatial audio sensing chain that is
accurate to ~0.09° in ideal conditions, ~2–3° on real compressed dashcam audio, runs in
3.38 ms p95, degrades honestly rather than silently, and refuses to emit artefacts when its
inputs are incomplete. That is a credible foundation.

The distance between that and an MVP is **entirely a training and data problem**, and it is
worth being blunt about the size of it: the current corpus is **one minute of audio**. No
amount of engineering closes that gap. The binding constraints, in order, are:

1. **Corpus size and diversity** — 3 clips, one country, 1 minute.
2. **Real-siren validation** — the synthetic source assumption is untested, and it is the
   assumption the entire result rests on.
3. **4 clips still blocked** by the YouTube gate (now unblocked in tooling; `--cookies` added).

Item 2 is the one that matters most. Even 10,000 clips of perfect synthetic audio would not
establish that this works on a real siren, because the question "does a real siren produce
this ITD signature in this cabin geometry" has never been asked of real audio.

---

## 6. Open items

| # | Item | Blocker | Owner action |
|---|---|---|---|
| 1 | `clip_metrics` domain guard (§3.1) | code defect | fix + regenerate report |
| 2 | Stale `poc_report.json` (§3.2) | code defect | regenerate after fix 1 |
| 3 | `nfft=32768` non-monotonicity | unexplained | investigate |
| 4 | Todos 5 + 9: WavLM precache, smoke training | needs CUDA | Colab T4 — runbook ready at `docs/COLAB_RUNBOOK.md`, bundle verified (179 pass, 9 skip from a clean extract) |
| 5 | C03/C05/C06/C07 | YouTube IP gate | Colab egress IP or `--cookies cookies.txt` |
| 6 | Real siren audio | sourcing | **needed before any MVP accuracy claim** |

**Per instruction, no fixes have been applied — this report is observation only.**